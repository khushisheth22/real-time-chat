// client/src/App.jsx
import React, { useContext, useState } from 'react';
import { AuthContext } from './contexts/AuthContext';
import Login from './components/Login';
import Register from './components/Register';
import Chat from './components/Chat';

export default function App() {
  const { user } = useContext(AuthContext);
  const [showRegister, setShowRegister] = useState(false);

  if (!user) {
    return (
      <div style={{ maxWidth: 420, margin: '30px auto', padding: 20, background: 'white', borderRadius:8 }}>
        {showRegister
          ? <><Register onDone={() => setShowRegister(false)} /><div style={{ marginTop:12 }}><button onClick={() => setShowRegister(false)}>Have an account? Login</button></div></>
          : <><Login onDone={() => {}} /><div style={{ marginTop:12 }}><button onClick={() => setShowRegister(true)}>Create account</button></div></>
        }
      </div>
    );
  }

  return <Chat />;
}
