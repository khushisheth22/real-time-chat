// client/src/components/Chat.jsx
import React, { useContext, useEffect, useState } from 'react';
import API from '../services/api';
import { connectSocket, getSocket, disconnectSocket } from '../services/socket';
import { AuthContext } from '../contexts/AuthContext';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import OnlineUsers from './OnlineUsers';

export default function Chat() {
  const { user, logout } = useContext(AuthContext);
  const [messages, setMessages] = useState([]);
  const [online, setOnline] = useState([]);
  const [typingUsers, setTypingUsers] = useState([]);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const s = connectSocket(token);
    setSocket(s);

    s.on('connect_error', (err) => {
      console.error('Socket error', err.message);
    });

    s.on('new_message', (msg) => {
      setMessages(prev => [...prev, msg]);
    });

    s.on('online_users', (users) => {
      setOnline(users);
    });

    s.on('typing', ({ username }) => {
      setTypingUsers(prev => {
        if (prev.includes(username)) return prev;
        return [...prev, username];
      });
    });

    s.on('stop_typing', ({ username }) => {
      setTypingUsers(prev => prev.filter(u => u !== username));
    });

    // fetch existing messages
    (async () => {
      try {
        const res = await API.get('/messages');
        setMessages(res.data || []);
      } catch (err) {
        console.error(err);
      }
    })();

    return () => {
      disconnectSocket();
    };
  }, []);

  const handleSend = (text) => {
    socket?.emit('send_message', { text });
  };

  return (
    <div className="app">
      <div className="header">
        <div><strong>Realtime Chat</strong></div>
        <div>
          <span className="small" style={{ marginRight: 10 }}>{user?.username}</span>
          <button onClick={logout}>Logout</button>
        </div>
      </div>

      <div className="container">
        <div className="sidebar">
          <OnlineUsers users={online} />
        </div>
        <div className="chat">
          <MessageList messages={messages} currentUser={user} typingUsers={typingUsers} />
          <MessageInput onSend={handleSend} socket={socket} />
        </div>
      </div>
    </div>
  );
}
