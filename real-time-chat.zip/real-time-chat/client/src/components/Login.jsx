// client/src/components/Login.jsx
import React, { useState, useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

export default function Login({ onDone }) {
  const { login } = useContext(AuthContext);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    try {
      setErr('');
      await login(username.trim(), password);
      onDone();
    } catch (e) {
      setErr(e.response?.data?.message || 'Login failed');
    }
  };

  return (
    <form onSubmit={submit} style={{ padding: 16 }}>
      <h3>Login</h3>
      <div>
        <input placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
      </div>
      <div style={{ marginTop:8 }}>
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      </div>
      <div style={{ marginTop:10 }}>
        <button type="submit">Login</button>
      </div>
      {err && <div style={{ color: 'red', marginTop:8 }}>{err}</div>}
    </form>
  );
}
