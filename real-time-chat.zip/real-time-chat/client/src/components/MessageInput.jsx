// client/src/components/MessageInput.jsx
import React, { useState, useEffect } from 'react';

export default function MessageInput({ onSend, socket }) {
  const [text, setText] = useState('');
  const [typing, setTyping] = useState(false);
  let typingTimeout = null;

  useEffect(() => {
    return () => clearTimeout(typingTimeout);
  }, []);

  const handleChange = (e) => {
    setText(e.target.value);
    if (!typing) {
      setTyping(true);
      socket?.emit('typing');
    }
    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => {
      setTyping(false);
      socket?.emit('stop_typing');
    }, 800);
  };

  const submit = (e) => {
    e.preventDefault();
    const t = text.trim();
    if (!t) return;
    onSend(t);
    setText('');
    socket?.emit('stop_typing');
    setTyping(false);
  };

  return (
    <form className="inputRow" onSubmit={submit}>
      <input value={text} onChange={handleChange} placeholder="Type a message..." />
      <button type="submit">Send</button>
    </form>
  );
}
