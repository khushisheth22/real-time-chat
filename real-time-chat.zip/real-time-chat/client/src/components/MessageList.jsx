// client/src/components/MessageList.jsx
import React, { useEffect, useRef } from 'react';

export default function MessageList({ messages, currentUser, typingUsers }) {
  const ref = useRef();
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [messages, typingUsers]);

  return (
    <div className="messages" ref={ref}>
      {messages.map((m) => (
        <div key={m._id || Math.random()} className={`message ${m.sender === currentUser?.username ? 'you' : ''}`}>
          <div style={{ fontSize: 12, color:'#374151' }}><strong>{m.sender}</strong> <span className="small">{new Date(m.createdAt).toLocaleTimeString()}</span></div>
          <div>{m.text}</div>
        </div>
      ))}
      {typingUsers.length > 0 && (
        <div className="small" style={{ marginTop:8 }}>{typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing…</div>
      )}
    </div>
  );
}
