// client/src/components/OnlineUsers.jsx
import React from 'react';

export default function OnlineUsers({ users }) {
  return (
    <div>
      <h4>Online ({users.length})</h4>
      {users.map(u => (
        <div key={u} className="onlineUser">{u}</div>
      ))}
    </div>
  );
}
