// client/src/components/Register.jsx
import React, { useState, useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

export default function Register({ onDone }) {
  const { register } = useContext(AuthContext);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    try {
      setErr('');
      await register(username.trim(), password);
      onDone();
    } catch (e) {
      setErr(e.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <form onSubmit={submit} style={{ padding: 16 }}>
      <h3>Create an account</h3>
      <div>
        <input placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
      </div>
      <div style={{ marginTop:8 }}>
        <input placeholder="Password (min 6)" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      </div>
      <div style={{ marginTop:10 }}>
        <button type="submit">Register</button>
      </div>
      {err && <div style={{ color: 'red', marginTop:8 }}>{err}</div>}
    </form>
  );
}
