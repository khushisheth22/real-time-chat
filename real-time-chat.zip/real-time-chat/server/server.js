// server/server.js
require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const msgRoutes = require('./routes/messages');
const Message = require('./models/Message');

const app = express();
const server = http.createServer(app);

// Socket.IO setup
const { Server } = require('socket.io');
const io = new Server(server, {
  cors: { origin: process.env.CLIENT_URL || 'http://localhost:5173', methods: ["GET", "POST"] }
});

connectDB(process.env.MONGODB_URI);

app.use(express.json());
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));

app.use('/api/auth', authRoutes);
app.use('/api/messages', msgRoutes);

const onlineUsers = new Map(); // username -> socketId (simple approach)

/** Socket auth helper */
const verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    return null;
  }
};

io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  const payload = verifyToken(token);
  if (!payload) {
    return next(new Error('unauthorized'));
  }
  socket.user = { id: payload.id, username: payload.username };
  next();
});

io.on('connection', (socket) => {
  const { username } = socket.user;
  onlineUsers.set(username, socket.id);

  // broadcast online users
  io.emit('online_users', Array.from(onlineUsers.keys()));

  // when someone sends a message
  socket.on('send_message', async (payload) => {
    try {
      // payload: { text }
      const text = String(payload.text || '').trim();
      if (!text) return;
      const newMsg = new Message({
        senderId: socket.user.id,
        sender: socket.user.username,
        text
      });
      await newMsg.save();
      io.emit('new_message', newMsg);
    } catch (err) {
      console.error('send_message error', err);
    }
  });

  socket.on('typing', () => {
    socket.broadcast.emit('typing', { username });
  });

  socket.on('stop_typing', () => {
    socket.broadcast.emit('stop_typing', { username });
  });

  socket.on('disconnect', () => {
    onlineUsers.delete(username);
    io.emit('online_users', Array.from(onlineUsers.keys()));
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server listening on ${PORT}`));
